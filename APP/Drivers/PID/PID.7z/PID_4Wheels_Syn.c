/*
 * pid.c
 *
 *  Created on: Jul 21, 2021
 *      Author: 李健
 */


#include "../PID/PID_4Wheels_Syn.h"

float Proportion = 0.2;
float Integral = 0;
float Derivative=0;

void showPID(void)
{
	float temp1,temp2,temp3;
	char PID_P[3],PID_I[3],PID_D[3];


	temp1 = Proportion;
	sprintf(PID_P,"%1.1f",temp1);
	ssd1306_SetCursor(16, 45);
	ssd1306_WriteString(PID_P, Font_7x10, White);

	temp2 = Integral;
	sprintf(PID_I,"%1.1f",temp2);
	ssd1306_SetCursor(56, 45);
	ssd1306_WriteString(PID_I, Font_7x10, White);

	temp3 = Derivative;
	sprintf(PID_D,"%1.1f",temp3);
	ssd1306_SetCursor(106, 45);
	ssd1306_WriteString(PID_D, Font_7x10, White);
}

/********************增量式PID控制设计************************************/
//NextPoint当前输出值
//SetPoint设定值

//左前A轮PID
uint8_t PID_Calc_A(uint8_t NextPoint,uint8_t SetPoint)
{

	static uint8_t      LastError;                                //Error[-1]
	static uint8_t      PrevError;                                //Error[-2]
	uint8_t iError,Outpid;                                        //当前误差

	iError=SetPoint-NextPoint;                                //增量计算
	Outpid=(Proportion * iError)                              //E[k]项
			  -(Integral * LastError)                       //E[k-1]项
			  +(Derivative * PrevError);                    //E[k-2]项

	PrevError=LastError;                                      //存储误差，用于下次计算
	LastError=iError;
	return(Outpid);                                           //返回增量值
}


//右前B轮PID
uint8_t PID_Calc_B(uint8_t NextPoint,uint8_t SetPoint)
{
	static uint8_t      LastError;                                //Error[-1]
	static uint8_t      PrevError;                                //Error[-2]
	uint8_t iError,Outpid;                                        //当前误差

	iError=SetPoint-NextPoint;                                //增量计算
	Outpid=(Proportion * iError)                              //E[k]项
			  -(Integral * LastError)                       //E[k-1]项
			  +(Derivative * PrevError);                    //E[k-2]项

	PrevError=LastError;                                      //存储误差，用于下次计算
	LastError=iError;
	return(Outpid);                                           //返回增量值
}

//右后C轮PID
uint8_t PID_Calc_C(uint8_t NextPoint,uint8_t SetPoint)
{

	static uint8_t      LastError;                                //Error[-1]
	static uint8_t      PrevError;                                //Error[-2]
	uint8_t iError,Outpid;                                        //当前误差

	iError=SetPoint-NextPoint;                                //增量计算
	Outpid=(Proportion * iError)                              //E[k]项
			  -(Integral * LastError)                       //E[k-1]项
			  +(Derivative * PrevError);                    //E[k-2]项

	PrevError=LastError;                                      //存储误差，用于下次计算
	LastError=iError;
	return(Outpid);                                           //返回增量值
}


//左后D轮PID
uint8_t PID_Calc_D(uint8_t NextPoint,uint8_t SetPoint)
{
	static uint8_t      LastError;                                //Error[-1]
	static uint8_t      PrevError;                                //Error[-2]
	uint8_t iError,Outpid;                                        //当前误差

	iError=SetPoint-NextPoint;                                //增量计算
	Outpid=(Proportion * iError)                              //E[k]项
			  -(Integral * LastError)                       //E[k-1]项
			  +(Derivative * PrevError);                    //E[k-2]项

	PrevError=LastError;                                      //存储误差，用于下次计算
	LastError=iError;
	return(Outpid);                                           //返回增量值
}
