/*
 * pid.h
 *
 *  Created on: Jul 21, 2021
 *      Author: 李健
 */

#ifndef PID_PID_H_
#define PID_PID_H_

#include "main.h"
#include "ssd1306.h"
#include <string.h>
uint8_t PID_Calc_A(uint8_t NextPoint,uint8_t Setpoint);
uint8_t PID_Calc_B(uint8_t NextPoint,uint8_t Setpoint);
uint8_t PID_Calc_C(uint8_t NextPoint,uint8_t Setpoint);
uint8_t PID_Calc_D(uint8_t NextPoint,uint8_t Setpoint);
void showPID(void);


#endif /* PID_PID_H_ */
